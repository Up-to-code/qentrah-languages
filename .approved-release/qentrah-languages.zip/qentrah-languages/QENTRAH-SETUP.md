# Qentrah Languages 0.3.1

Edition: qentrah-languages
Source revision: 08d72a31c4c46c306e7a6c781fe3ebf065fa822a

In WordPress open Plugins → Add New → Upload Plugin and select the plugin ZIP. The manual ZIP is a separate document.

Runtime: {"node": "22", "php": "8.2"}
License terms are supplied with your purchase certificate. Third-party notices remain applicable.
